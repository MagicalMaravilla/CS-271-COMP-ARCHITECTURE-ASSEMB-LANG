import unittest
from assembler import Assembler

class TestAssembler(unittest.TestCase):

    def setUp(self):
        # Initialize an Assembler instance and define a sample filename and assembly commands
        self.assembler = Assembler()
        self.filename = 'test'
        self.acommands = [
            '@2',       # A-instruction to set A register to 2
            'D=A',      # C-instruction to set D register to the value of A register
            '@3',       # A-instruction to set A register to 3
            'D=D+A',    # C-instruction to add A register to D register
            '@0',       # A-instruction to set A register to 0
            'M=D',      # C-instruction to set RAM[A] to the value of D register
            '(LOOP)',   # Label definition for LOOP
            '@LOOP',    # A-instruction to set A register to the address of LOOP
            '0;JMP'     # C-instruction to jump unconditionally
        ]

    def test_parse_file(self):
        # Test if the parse_file method correctly reads and cleans the assembly file
        acommands = self.assembler.parse_file(self.filename)
        self.assertEqual(acommands, self.acommands)

    def test_handle_labels(self):
        # Test if the handle_labels method correctly processes label definitions
        asm = self.assembler.handle_labels(self.acommands)
        expected_asm = ['@2', 'D=A', '@3', 'D=D+A', '@0', 'M=D', '@LOOP', '0;JMP']
        self.assertEqual(asm, expected_asm)

    def test_handle_variables(self):
        # Test if the handle_variables method correctly assigns addresses to variables
        asm = self.assembler.handle_labels(self.acommands)
        self.assembler.handle_variables(asm)
        self.assertIn('LOOP', self.assembler.symbols)  # Check if LOOP label is in symbols
        self.assertEqual(self.assembler.symbols['LOOP'], 6)  # Check if LOOP label is assigned the correct address

    def test_generate_machine_code(self):
        # Test if the generate_machine_code method correctly generates binary machine code
        asm = self.assembler.handle_labels(self.acommands)
        self.assembler.handle_variables(asm)
        self.assembler.generate_machine_code(asm, self.filename)
        with open(self.filename + '1.hack', 'r') as f:
            machine_code = f.readlines()
        expected_code = [
            '0000000000000010\n',  # Binary code for @2
            '1110110000010000\n',  # Binary code for D=A
            '0000000000000011\n',  # Binary code for @3
            '1110000010010000\n',  # Binary code for D=D+A
            '0000000000000000\n',  # Binary code for @0
            '1110001100001000\n',  # Binary code for M=D
            '0000000000000110\n',  # Binary code for @6 (LOOP label address)
            '1110101010000111\n'   # Binary code for 0;JMP
        ]
        self.assertEqual(machine_code, expected_code)

if __name__ == '__main__':
    unittest.main()
