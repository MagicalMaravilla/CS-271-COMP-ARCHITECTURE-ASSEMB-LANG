import re

class Assembler:
    def __init__(self):
        # Initialize dictionaries for translating assembly language components to binary
        self.dest = {'':'000', 'M=':'001', 'D=':'010', 'MD=':'011', 'A=':'100', 'AM=':'101', 'AD=':'110', 'AMD=':'111'}
        self.jump = {'':'000', ';JGT':'001', ';JEQ':'010', ';JGE':'011', ';JLT':'100', ';JNE':'101', ';JLE':'110', ';JMP':'111'}
        self.comp = {'0':'0101010', '1':'0111111', '-1':'0111010', 'D':'0001100', 'A':'0110000', 'M':'1110000',
                     '!D':'0001101', '!A':'0110001', '!M':'1110001', '-D':'0001111', '-A':'0110011', '-M':'1110011',
                     'D+1':'0011111', 'A+1':'0110111', 'M+1':'1110111', 'D-1':'0001110', 'A-1':'0110010', 'M-1':'1110010',
                     'D+A':'0000010', 'D+M':'1000010', 'D-A':'0010011', 'D-M':'1010011', 'A-D':'0000111', 'M-D':'1000111',
                     'D&A':'0000000', 'D&M':'1000000', 'D|A':'0010101', 'D|M':'1010101'}
        self.symbols = {'SP':0, 'LCL':1, 'ARG':2, 'THIS':3, 'THAT':4, 'SCREEN':16384, 'KBD':24576,
                        'R0':0, 'R1':1, 'R2':2, 'R3':3, 'R4':4, 'R5':5, 'R6':6, 'R7':7,
                        'R8':8, 'R9':9, 'R10':10, 'R11':11, 'R12':12, 'R13':13, 'R14':14, 'R15':15}

    def parse_file(self, filename):
        acommands = []  # List to store cleaned assembly commands
        asmfile = open(filename + '.asm', 'r')  # Open the .asm file for reading
        for line in asmfile:
            ln = re.sub(r'\/+.*\n|\n| *', '', line)  # Remove comments and whitespace
            if ln != '':
                acommands.append(ln)  # Add cleaned line to the list if it's not empty
        asmfile.close()  # Close the file
        return acommands

    def handle_labels(self, acommands):
        lineno = 0
        for command in acommands:
            symbol = re.findall(r'\(.+\)', command)  # Find label definitions
            if symbol != []:
                if symbol[0][1:-1] not in self.symbols:  # If label is not already in symbols
                    self.symbols[symbol[0][1:-1]] = lineno  # Add label with its line number
                    lineno -= 1
            lineno += 1
        asm = []
        for line in acommands:
            ln = re.sub(r'\(.+\)', '', line)  # Remove label definitions from commands
            if ln != '':
                asm.append(ln)  # Add cleaned command to the list if it's not empty
        return asm

    def handle_variables(self, asm):
        variableno = 16  # Start address for user-defined variables
        for command in asm:
            symbol = re.findall(r'@[a-zA-Z]+.*', command)  # Find variable symbols
            if symbol != []:
                if symbol[0][1:] not in self.symbols:  # If variable is not already in symbols
                    self.symbols[symbol[0][1:]] = variableno  # Add variable with its address
                    variableno += 1

    def generate_machine_code(self, asm, filename):
        hackfile = open(filename + '1.hack', 'w')  # Open the .hack file for writing
        for command in asm:
            if command[0] == '@':  # A-instruction
                address = 0
                if command[1:] in self.symbols:
                    address = self.symbols[command[1:]] + 32768  # Convert symbol to address
                else:
                    address = int(command[1:]) + 32768  # Convert number to address
                hackfile.write('0' + bin(address)[3:] + '\n')  # Write binary A-instruction
            else:  # C-instruction
                de = re.findall(r'.+=', command)
                if de != []:
                    d = self.dest[str(de[0])]  # Get binary code for destination
                else:
                    d = self.dest['']
                je = re.findall(r';.+', command)
                if je != []:
                    j = self.jump[str(je[0])]  # Get binary code for jump
                else:
                    j = self.jump['']
                c = self.comp[re.sub(r'.+=|;.+', '', command)]  # Get binary code for computation
                hackfile.write('111' + c + d + j + '\n')  # Write binary C-instruction
        hackfile.close()

if __name__ == "__main__":
    assembler = Assembler()
    f = input('File:')  # Get filename from user input
    acommands = assembler.parse_file(f)  # Parse the file to get assembly commands
    asm = assembler.handle_labels(acommands)  # Handle labels in the commands
    assembler.handle_variables(asm)  # Handle variables in the commands
    assembler.generate_machine_code(asm, f)  # Generate machine code and save to .hack file
