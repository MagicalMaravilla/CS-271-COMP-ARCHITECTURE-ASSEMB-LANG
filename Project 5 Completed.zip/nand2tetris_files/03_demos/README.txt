Demo videos can be found here: https://www.nand2tetris.org/demos

As of 03 February, we have these video demos:
  - Hardware Simulator: First Look: 
	https://www.youtube.com/watch?v=FW6Z_Xp2v-c&list=PLYM3zllSC3SVdjWQUfedxssewHRS7EHuA
  - HDL-Based Chip Simulation:
	https://www.youtube.com/watch?v=iSNfqzJUWW4&list=PLYM3zllSC3SVdjWQUfedxssewHRS7EHuA&index=3
  - Script-Based Chip Simulation:
	https://www.youtube.com/watch?v=d0X0dMMUt1U&list=PLYM3zllSC3SVdjWQUfedxssewHRS7EHuA&index=4
  - Clock Demo:
	https://www.youtube.com/watch?v=VFXPGIw_Odo&list=PLYM3zllSC3SVdjWQUfedxssewHRS7EHuA&index=5
  - Register Demo:
	https://www.youtube.com/watch?v=URds-xtD5A0&list=PLYM3zllSC3SVdjWQUfedxssewHRS7EHuA&index=6
  - Program Counter Demo:
	https://www.youtube.com/watch?v=PECRzxWh1Ho&list=PLYM3zllSC3SVdjWQUfedxssewHRS7EHuA&index=7
  - RAM Demo:
	https://www.youtube.com/watch?v=-99WGl31dcA&list=PLYM3zllSC3SVdjWQUfedxssewHRS7EHuA&index=8
  - CPU Emulator Demo:
	https://www.youtube.com/watch?v=8XieZhHNFVY
	also found in that playlist here (not checked if video is different in any way):
	  https://www.youtube.com/watch?v=8XieZhHNFVY&list=PLYM3zllSC3SVdjWQUfedxssewHRS7EHuA&index=9
  - CPU Emulator Demo: Executing a simple graphics program:
	https://www.youtube.com/watch?v=20CHjI8M2gU&list=PLYM3zllSC3SVdjWQUfedxssewHRS7EHuA&index=10
  - CPU Emulator Demo: Executing Pong:
	https://www.youtube.com/watch?v=NMG-7e7d_jE&list=PLYM3zllSC3SVdjWQUfedxssewHRS7EHuA&index=11
  - Screen Chip Demo:
	https://www.youtube.com/watch?v=Z-Wl9MEeChk&list=PLYM3zllSC3SVdjWQUfedxssewHRS7EHuA&index=12
  - Keyboard Chip Demo:
	https://www.youtube.com/watch?v=XLH2wRjtiHA&list=PLYM3zllSC3SVdjWQUfedxssewHRS7EHuA&index=13
  - ROM Demo:
	https://www.youtube.com/watch?v=7rXFuyiCHi8&list=PLYM3zllSC3SVdjWQUfedxssewHRS7EHuA&index=14
