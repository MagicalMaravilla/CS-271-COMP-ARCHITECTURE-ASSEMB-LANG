Note as of 03 February, 2022: these papers had links, but none went to valid locations according to Google Drive.

Papers
Some papers about the course and the approach are available: 

Taming Complexity in Large Scale Systems Projects, SIGCSE 2012. 

Virtual Machines: Abstraction and Implementation, ITiCSE 2009. 

A Synthesis Course in Hardware Architecture, Compilers, and Software Engineering, SIGCSE 2009.